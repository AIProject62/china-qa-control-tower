China QA Dummy Upload Test Kit

Recommended sequence:
1. Upload China_QA_Dummy_Quality_Upload.csv. This REPLACES the active Quality dataset.
2. Upload China_QA_Dummy_SCM_Upload.csv. This REPLACES the active SCM production master.
3. Optional: Evidence mode = Add to current evidence, then upload China_QA_Dummy_Evidence.zip.
4. Optional: upload China_QA_Dummy_Evidence_Mapping.csv under Optional OA / batch mapping.

Expected checks:
- Most dummy rows become READY after both Quality and SCM are loaded.
- SKU 990004 -> NO_PROD.
- SKU 990005 -> AMBIG_MULTI_PLANT.
- 990006 tests SMD -> K103.
- 990007 tests RCK -> K104.
- 990008 tests MJL -> K118.
- Claims include fully paid, partially paid, unpaid, and missing payment data.
- SCCC000000001 has more than one Issue Classification to test OA overlap.

To return to the original dashboard data, click Restore all embedded data or reopen the HTML.
